class ViewShurima:
    def display(self, data):
        print(f"Data: {data}")
