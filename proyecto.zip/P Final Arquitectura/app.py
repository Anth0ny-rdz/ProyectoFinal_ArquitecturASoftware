import sqlite3
import os
from flask import Flask, request, redirect, url_for, render_template, flash
import requests
import sys

# Add QueueManager directory to PYTHONPATH
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from controllers.controller_shurima import ControllerShurima  # Import the controller

controller = ControllerShurima()

app = Flask(__name__)
app.secret_key = b'\x8c\x88\x17O\xd2\xfdx\xa6\xb6\x9e\x15\xdfS\x980\xe8\xf4\x19\x80\xb3H\xa6\xf83'

# URL of the new time API
TIME_API_URL = 'http://localhost:5000/api/times'

@app.route('/')
def index():
    try:
        print("Fetching reservations from the API...")
        response = requests.get(TIME_API_URL)
        response.raise_for_status()
        reservations = response.json()

        conn = get_db_connection()
        c = conn.cursor()
        c.execute('SELECT * FROM places')
        places = c.fetchall()
        conn.close()

        places = [dict(row) for row in places]

        print(f"Reservations fetched: {reservations}")
        print(f"Places fetched: {places}")

        return render_template('index.html', reservations=reservations, places=places)
    except Exception as e:
        print(f"Error: {e}")
        return f"An error occurred while fetching data from the database: {e}"

@app.route('/reserve', methods=['POST'])
def reserve():
    name = request.form['name']
    email = request.form['email']
    date = request.form['date']
    time = request.form['time']
    type = request.form['type']

    try:
        print(f"Checking availability for {date} {time} {type}...")
        response = requests.get(TIME_API_URL, params={'date': date, 'time': time, 'type': type})
        response.raise_for_status()
        availability = response.json()

        if not availability['available']:
            flash('The reservation already exists for the specified date and time.', 'error')
            return redirect(url_for('index'))

        new_reservation = {
            'name': name,
            'email': email,
            'date': date,
            'time': time,
            'type': type
        }
        print("Making the reservation...")
        response = requests.post(TIME_API_URL, json=new_reservation)
        response.raise_for_status()

        flash('Reservation successfully made.', 'success')

        reservation = response.json()
        print(f"Reservation made: {reservation}")

        controller.add_reservation(reservation)

        return redirect(url_for('index'))
    except Exception as e:
        print(f"Error: {e}")
        flash('An error occurred while making the reservation.', 'error')
        return redirect(url_for('index'))

@app.route('/check_availability', methods=['GET'])
def check_availability():
    date = request.args.get('date')
    time = request.args.get('time')
    type = request.args.get('type')

    print(f"Checking availability for date: {date}, time: {time}, type: {type}")

    try:
        response = requests.get(TIME_API_URL, params={'date': date, 'time': time, 'type': type})
        response.raise_for_status()
        availability = response.json()

        return availability
    except Exception as e:
        print(f"Error: {e}")
        return {"available": False, "error": str(e)}

# Define the database directory
DATABASE = os.path.join(os.path.dirname(__file__), 'database', 'places.sql')

def get_db_connection():
    try:
        if not os.path.exists(DATABASE):
            print(f"Database file {DATABASE} does not exist!")
            raise FileNotFoundError(f"Database file {DATABASE} not found.")
        else:
            print(f"Database file {DATABASE} found.")
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Error connecting to the database: {e}")
        raise

if __name__ == '__main__':
    app.run(debug=True)
