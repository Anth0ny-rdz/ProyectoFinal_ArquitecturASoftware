import sqlite3
import os

print("Starting database initialization...")

# Ensure the 'database' directory exists
DATABASE_DIR = os.path.join(os.path.dirname(__file__), '..', 'database')
if not os.path.exists(DATABASE_DIR):
    print(f"Creating directory: {DATABASE_DIR}")
    os.makedirs(DATABASE_DIR)

DATABASE = os.path.join(DATABASE_DIR, 'reservations.db')
print(f"Database path: {DATABASE}")

def init_db():
    print("Connecting to the database...")
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    print("Creating table if not exists...")
    c.execute('''
    CREATE TABLE IF NOT EXISTS reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        type TEXT NOT NULL
    )
    ''')
    conn.commit()
    conn.close()
    print("Database initialization completed.")

if __name__ == '__main__':
    init_db()
    print("Script execution completed.")
