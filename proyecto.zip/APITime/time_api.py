from flask import Blueprint, request, jsonify
import sqlite3
import os

time_api = Blueprint('time_api', __name__)

DATABASE = os.path.join(os.path.dirname(__file__), 'database', 'reservations.db')

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # Obtener filas como diccionarios
    return conn

@time_api.route('/api/times', methods=['GET'])
def get_times():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('SELECT * FROM reservations')
    reservations = c.fetchall()
    conn.close()
    
    reservations = [dict(row) for row in reservations]  # Convertir filas a diccionarios
    return jsonify(reservations)

@time_api.route('/api/times', methods=['POST'])
def add_time():
    new_reservation = request.json
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('INSERT INTO reservations (name, date, time, type) VALUES (?, ?, ?, ?)',
              (new_reservation['name'], new_reservation['date'], new_reservation['time'], new_reservation['type']))
    conn.commit()
    conn.close()
    return jsonify(new_reservation), 201

@time_api.route('/api/times/<int:id>', methods=['DELETE'])
def delete_time(id):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('DELETE FROM reservations WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return '', 204
